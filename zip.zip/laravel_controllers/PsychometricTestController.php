<?php

namespace App\Http\Controllers;

use App\Models\PsychometricTest;
use App\Models\PsychometricQuestion;
use App\Models\PsychometricScore;
use Illuminate\Http\Request;

class PsychometricTestController extends Controller
{
    public function suggest(Request $request)
    {
        return response()->json(PsychometricTest::all());
    }

    public function show($slug)
    {
        $test = PsychometricTest::where('slug', $slug)->firstOrFail();
        $questions = $test->questions()->orderBy('order')->get();

        return response()->json([
            'test' => $test->name,
            'description' => $test->description,
            'questions' => $questions,
            'options' => $test->options,
        ]);
    }

    public function submit(Request $request, $slug)
    {
        $test = PsychometricTest::where('slug', $slug)->firstOrFail();

        $validated = $request->validate([
            'answers' => 'required|array',
            'user_id' => 'required|uuid',
        ]);

        $score = array_sum(array_values($validated['answers']));

        $entry = PsychometricScore::create([
            'user_id' => $validated['user_id'],
            'test_id' => $test->id,
            'answers' => $validated['answers'],
            'score' => $score,
        ]);

        return response()->json(['success' => true, 'score' => $score, 'id' => $entry->id]);
    }
}
